from __future__ import annotations

import re
import uuid
from pathlib import Path

from fpdf import FPDF

BASE_DIR = Path(__file__).resolve().parent.parent
EXPORT_DIR = BASE_DIR / "static" / "exports"

def _plain(text: str) -> str:
    # Core PDF fonts are not Unicode-complete; keep export robust on Windows.
    text = text or ""
    replacements = {
        "—": "-", "–": "-", "’": "'", "‘": "'",
        "“": '"', "”": '"', "…": "...",
        "•": "-", "₹": "Rs.",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text.encode("latin-1", "replace").decode("latin-1")

def _local_image(path: str) -> Path:
    if path.startswith("/static/"):
        return BASE_DIR / path.lstrip("/")
    return Path(path)

def save_pdf(layout: list[dict], title: str = "ComicCraft Comic") -> str:
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    filename = f"comic_{uuid.uuid4().hex[:12]}.pdf"
    output = EXPORT_DIR / filename

    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in layout:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.multi_cell(0, 10, _plain(f"Panel {panel['panel_number']}: {panel['title']}"))

        image_file = _local_image(panel["image_path"])
        if image_file.exists():
            x = 15
            y = pdf.get_y() + 3
            max_w, max_h = 180, 105
            pdf.image(str(image_file), x=x, y=y, w=max_w, h=max_h)
            pdf.set_y(y + max_h + 8)

        pdf.set_font("Helvetica", "I", 10)
        pdf.multi_cell(0, 6, _plain(panel["scene_description"]))
        pdf.ln(2)

        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, _plain("Caption"))
        pdf.set_font("Helvetica", "", 11)
        pdf.multi_cell(0, 6, _plain(panel["caption"]))
        pdf.ln(1)

        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, _plain("Narration"))
        pdf.set_font("Helvetica", "", 11)
        pdf.multi_cell(0, 6, _plain(panel["narration"]))

        if panel.get("dialogue"):
            pdf.ln(2)
            pdf.set_font("Helvetica", "B", 11)
            pdf.multi_cell(0, 6, _plain("Dialogue"))
            pdf.set_font("Helvetica", "", 11)
            pdf.multi_cell(0, 6, _plain(panel["dialogue"]))

    pdf.output(str(output))
    return f"/static/exports/{filename}"
