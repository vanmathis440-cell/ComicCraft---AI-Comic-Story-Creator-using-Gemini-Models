from google import genai
from google.genai import types

from .config import get_settings
from .schemas import ComicOutline

settings = get_settings()

def _client() -> genai.Client:
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is missing. Add it to your .env file.")
    return genai.Client(api_key=settings.gemini_api_key)

def generate_outline(
    story_prompt: str,
    character_name: str,
    setting: str,
    tone: str,
    art_style: str,
) -> list[dict]:
    prompt = f"""
Create a cohesive five-panel comic outline.

User story idea: {story_prompt}
Main character: {character_name}
Setting: {setting}
Tone: {tone}
Art style: {art_style}

Requirements:
- Exactly 5 panels.
- Keep the same main character and visual identity across all panels.
- Panel 1 establishes the situation.
- Panels 2-4 develop the conflict/adventure.
- Panel 5 gives a satisfying ending.
- scene_description should describe visible action, environment, lighting and composition.
- image_prompt must be a detailed prompt for an image generator.
- Do not put speech bubbles or readable text inside the generated image.
- Avoid changing the character's appearance between panels.
"""

    response = _client().models.generate_content(
        model=settings.gemini_flash_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=ComicOutline,
            system_instruction=(
                "You are a professional comic storyboard artist. "
                "Return only the requested structured data."
            ),
        ),
    )

    if getattr(response, "parsed", None):
        outline = response.parsed
    else:
        outline = ComicOutline.model_validate_json(response.text)

    panels = outline.panels
    if len(panels) != 5:
        raise RuntimeError(f"Gemini returned {len(panels)} panels; exactly 5 are required.")

    panels.sort(key=lambda p: p.panel_number)
    for index, panel in enumerate(panels, start=1):
        panel.panel_number = index
    return [panel.model_dump() for panel in panels]
