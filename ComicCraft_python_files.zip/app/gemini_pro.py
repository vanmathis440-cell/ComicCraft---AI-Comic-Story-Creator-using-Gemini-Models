from google import genai
from google.genai import types

from .config import get_settings
from .schemas import ComicStory

settings = get_settings()

def _client() -> genai.Client:
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is missing. Add it to your .env file.")
    return genai.Client(api_key=settings.gemini_api_key)

def generate_story(
    outline: list[dict],
    story_prompt: str,
    character_name: str,
    setting: str,
    tone: str,
    art_style: str,
) -> list[dict]:
    prompt = f"""
Expand this five-panel storyboard into a polished comic script.

Original idea: {story_prompt}
Character: {character_name}
Setting: {setting}
Tone: {tone}
Art style: {art_style}

Storyboard:
{outline}

For every panel provide:
- panel_number
- title
- scene_description
- caption: short environmental/action caption
- narration: 1-3 concise sentences
- dialogue: natural character dialogue; use an empty string if no dialogue is needed
- image_prompt: detailed visual prompt preserving character continuity

Keep the story coherent from panel 1 through panel 5.
Do not put quotation marks around the entire response.
Do not request readable text in the image itself.
"""

    response = _client().models.generate_content(
        model=settings.gemini_pro_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=ComicStory,
            system_instruction=(
                "You are an expert comic writer and dialogue editor. "
                "Return exactly five connected comic panels."
            ),
        ),
    )

    if getattr(response, "parsed", None):
        story = response.parsed
    else:
        story = ComicStory.model_validate_json(response.text)

    panels = story.panels
    if len(panels) != 5:
        raise RuntimeError(f"Gemini returned {len(panels)} story panels; exactly 5 are required.")

    panels.sort(key=lambda p: p.panel_number)
    for index, panel in enumerate(panels, start=1):
        panel.panel_number = index
    return [panel.model_dump() for panel in panels]
