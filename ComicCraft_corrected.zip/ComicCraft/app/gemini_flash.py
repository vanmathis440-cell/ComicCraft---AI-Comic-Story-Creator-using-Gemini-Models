from google import genai
from .config import get_settings
from .schemas import ComicOutline

settings = get_settings()

def _client() -> genai.Client:
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is missing. Add it to your .env file.")
    return genai.Client(api_key=settings.gemini_api_key)

def generate_outline(
    story_prompt: str,
    character_name: str,
    setting: str,
    tone: str,
    art_style: str,
) -> list[dict]:
    prompt = f"""
Create a cohesive five-panel comic outline.

User story idea: {story_prompt}
Main character: {character_name}
Setting: {setting}
Tone: {tone}
Art style: {art_style}

Requirements:
- Exactly 5 panels.
- Keep the same main character and visual identity across all panels.
- Panel 1 establishes the situation.
- Panels 2-4 develop the conflict/adventure.
- Panel 5 gives a satisfying ending.
- scene_description should describe visible action, environment, lighting and composition.
- image_prompt must be a detailed prompt for an image generator.
- Do not put speech bubbles or readable text inside the generated image.
- Avoid changing the character's appearance between panels.
"""

    interaction = _client().interactions.create(
        model=settings.gemini_flash_model,
        input=(
            "You are a professional comic storyboard artist. Return only the requested structured data.\n\n"
            + prompt
        ),
        response_format={
            "type": "text",
            "mime_type": "application/json",
            "schema": ComicOutline.model_json_schema(),
        },
    )

    output_text = getattr(interaction, "output_text", None)
    if not output_text:
        raise RuntimeError("Gemini returned no structured text output.")
    outline_obj = ComicOutline.model_validate_json(output_text)

    outline = outline_obj
    panels = outline.panels
    if len(panels) != 5:
        raise RuntimeError(f"Gemini returned {len(panels)} panels; exactly 5 are required.")

    panels.sort(key=lambda p: p.panel_number)
    for index, panel in enumerate(panels, start=1):
        panel.panel_number = index
    return [panel.model_dump() for panel in panels]
