from __future__ import annotations

import json
from pathlib import Path
from urllib.parse import quote

from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates

from .config import get_settings
from .exporters import save_pdf
from .gemini_flash import generate_outline
from .gemini_pro import generate_story
from .image_generator import generate_image
from .layout_builder import build_comic_layout
from .schemas import PromptRequest

BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
router = APIRouter()
settings = get_settings()

def _generate_pipeline(data: PromptRequest) -> tuple[list[dict], str]:
    outline = generate_outline(
        data.story_prompt, data.character_name, data.setting, data.tone, data.art_style
    )
    story = generate_story(
        outline,
        data.story_prompt,
        data.character_name,
        data.setting,
        data.tone,
        data.art_style,
    )

    images = []
    for panel in story:
        visual_prompt = (
            f"{panel['image_prompt']}. "
            f"Consistent character: {data.character_name}. "
            f"Setting: {data.setting}. Style: {data.art_style}. Tone: {data.tone}. "
            "Professional comic illustration, strong composition, expressive characters, "
            "clean details, no text, no watermark."
        )
        images.append(generate_image(visual_prompt, panel["panel_number"]))

    layout = build_comic_layout(story, images)
    pdf_path = save_pdf(layout, f"{data.character_name} Comic")
    return layout, pdf_path

@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@router.post("/generate", response_class=HTMLResponse)
async def generate_form(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        data = PromptRequest(
            story_prompt=story_prompt,
            character_name=character_name,
            setting=setting,
            tone=tone,
            art_style=art_style,
        )
        layout, pdf_path = _generate_pipeline(data)
        return templates.TemplateResponse(
            "comic_preview.html",
            {
                "request": request,
                "layout": layout,
                "pdf_path": pdf_path,
                "character_name": data.character_name,
            },
        )
    except Exception as exc:
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "error": str(exc),
                "form": {
                    "story_prompt": story_prompt,
                    "character_name": character_name,
                    "setting": setting,
                    "tone": tone,
                    "art_style": art_style,
                },
            },
            status_code=500,
        )

@router.post("/generate-comic/json")
async def generate_json(payload: PromptRequest):
    try:
        layout, pdf_path = _generate_pipeline(payload)
        return JSONResponse(
            {
                "success": True,
                "panels": layout,
                "pdf_path": pdf_path,
            }
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

@router.post("/test-image")
async def test_image(payload: dict):
    prompt = str(payload.get("prompt", "")).strip()
    if not prompt:
        raise HTTPException(status_code=400, detail="prompt is required")
    try:
        image_path = generate_image(prompt, 1)
        return {"success": True, "image_path": image_path}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request):
    return templates.TemplateResponse(
        "export_success.html",
        {"request": request},
    )

@router.get("/download/{filename}")
async def download_pdf(filename: str):
    # Prevent path traversal.
    safe_name = Path(filename).name
    pdf_file = BASE_DIR / "static" / "exports" / safe_name
    if not pdf_file.exists() or pdf_file.suffix.lower() != ".pdf":
        raise HTTPException(status_code=404, detail="PDF not found")
    return FileResponse(
        pdf_file,
        media_type="application/pdf",
        filename=safe_name,
        headers={"X-ComicCraft-Success-Redirect": "/export-success"},
    )
