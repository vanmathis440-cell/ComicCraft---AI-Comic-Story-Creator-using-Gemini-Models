def build_comic_layout(
    story: list[dict],
    image_paths: list[str],
) -> list[dict]:
    if len(story) != 5 or len(image_paths) != 5:
        raise ValueError("ComicCraft requires exactly five story panels and five images.")

    layout = []
    for panel, image_path in zip(sorted(story, key=lambda p: p["panel_number"]), image_paths):
        layout.append({
            "panel_number": panel["panel_number"],
            "title": panel["title"],
            "image_path": image_path,
            "scene_description": panel["scene_description"],
            "caption": panel["caption"],
            "narration": panel["narration"],
            "dialogue": panel["dialogue"],
            "image_prompt": panel["image_prompt"],
        })
    return layout
