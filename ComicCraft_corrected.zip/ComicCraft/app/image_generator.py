from __future__ import annotations

import re
import uuid
from pathlib import Path
from typing import Optional

from PIL import Image, ImageDraw, ImageFont

from .config import get_settings

BASE_DIR = Path(__file__).resolve().parent.parent
PANEL_DIR = BASE_DIR / "static" / "panels"

settings = get_settings()
_diffusers_pipe = None

def _safe_name(text: str) -> str:
    text = re.sub(r"[^a-zA-Z0-9_-]+", "_", text).strip("_")
    return (text[:60] or "panel")

def _placeholder_image(prompt: str, output_path: Path, panel_number: Optional[int] = None) -> str:
    """
    A deterministic local fallback. It lets the whole application and PDF pipeline
    be tested even when no GPU/model/API is available.
    """
    width, height = settings.image_width, settings.image_height
    image = Image.new("RGB", (width, height), (245, 239, 226))
    draw = ImageDraw.Draw(image)

    try:
        font = ImageFont.truetype("arial.ttf", 28)
        small = ImageFont.truetype("arial.ttf", 18)
    except Exception:
        font = ImageFont.load_default()
        small = ImageFont.load_default()

    title = f"COMICCRAFT — PANEL {panel_number or ''}".strip()
    draw.rectangle((24, 24, width - 24, height - 24), outline=(35, 35, 35), width=5)
    draw.text((45, 45), title, fill=(25, 25, 25), font=font)

    # Simple comic-style visual placeholder.
    cx, cy = width // 2, height // 2 + 20
    draw.ellipse((cx - 105, cy - 105, cx + 105, cy + 105), outline=(25, 25, 25), width=5)
    draw.ellipse((cx - 55, cy - 45, cx - 35, cy - 25), fill=(25, 25, 25))
    draw.ellipse((cx + 35, cy - 45, cx + 55, cy - 25), fill=(25, 25, 25))
    draw.arc((cx - 55, cy - 5, cx + 55, cy + 65), 10, 170, fill=(25, 25, 25), width=4)
    draw.text(
        (45, height - 100),
        "Image provider not configured.\nAdd HF_API_KEY / use Gemini image generation.",
        fill=(45, 45, 45),
        font=small,
    )
    image.save(output_path)
    return f"/static/panels/{output_path.name}"

def _get_diffusers_pipe():
    global _diffusers_pipe
    if _diffusers_pipe is not None:
        return _diffusers_pipe

    try:
        import torch
        from diffusers import StableDiffusionPipeline
    except ImportError as exc:
        raise RuntimeError(
            "Diffusers/PyTorch is not installed. Install the full requirements or "
            "switch IMAGE_PROVIDER to gemini or placeholder."
        ) from exc

    model_id = settings.hf_image_model
    dtype = torch.float16 if torch.cuda.is_available() else torch.float32

    kwargs = {"torch_dtype": dtype}
    if settings.hf_api_key:
        kwargs["token"] = settings.hf_api_key

    _diffusers_pipe = StableDiffusionPipeline.from_pretrained(model_id, **kwargs)

    if settings.model_device == "cuda" or (
        settings.model_device == "auto" and torch.cuda.is_available()
    ):
        _diffusers_pipe = _diffusers_pipe.to("cuda")
    else:
        _diffusers_pipe = _diffusers_pipe.to("cpu")

    return _diffusers_pipe

def _generate_diffusers(prompt: str, output_path: Path) -> str:
    pipe = _get_diffusers_pipe()
    generator = None
    try:
        import torch
        device = "cuda" if torch.cuda.is_available() else "cpu"
        generator = torch.Generator(device=device).manual_seed(settings.seed)
    except Exception:
        pass

    result = pipe(
        prompt=prompt,
        negative_prompt=(
            "blurry, distorted face, extra limbs, duplicate character, "
            "watermark, logo, text, letters, low quality"
        ),
        width=settings.image_width,
        height=settings.image_height,
        num_inference_steps=settings.image_steps,
        guidance_scale=7.0,
        generator=generator,
    )
    result.images[0].save(output_path)
    return f"/static/panels/{output_path.name}"

def _generate_gemini_image(prompt: str, output_path: Path) -> str:
    """Generate an image with Gemini's current Interactions API."""
    import base64
    from google import genai

    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is required for Gemini image generation.")

    client = genai.Client(api_key=settings.gemini_api_key)
    interaction = client.interactions.create(
        model=settings.gemini_image_model,
        input=(
            "Create a single comic panel illustration. "
            "Do not include readable text, captions, logos, or watermarks. "
            "Preserve the requested character identity and visual continuity. "
            f"Visual prompt: {prompt}"
        ),
        response_format={
            "type": "image",
            "mime_type": "image/png",
            "aspect_ratio": "1:1",
            "image_size": "1K",
        },
    )

    image = getattr(interaction, "output_image", None)
    data = getattr(image, "data", None) if image is not None else None
    if not data:
        raise RuntimeError(
            "Gemini image generation returned no image data. "
            "Check GEMINI_IMAGE_MODEL and your API access."
        )

    if isinstance(data, str):
        image_bytes = base64.b64decode(data)
    else:
        image_bytes = data

    output_path.write_bytes(image_bytes)
    return f"/static/panels/{output_path.name}"


def generate_image(prompt: str, panel_number: Optional[int] = None) -> str:
    PANEL_DIR.mkdir(parents=True, exist_ok=True)
    filename = f"{_safe_name(prompt)[:45]}_{uuid.uuid4().hex[:8]}.png"
    output_path = PANEL_DIR / filename

    provider = settings.image_provider.lower().strip()

    if provider == "placeholder":
        return _placeholder_image(prompt, output_path, panel_number)

    if provider == "gemini":
        return _generate_gemini_image(prompt, output_path)

    if provider == "diffusers":
        return _generate_diffusers(prompt, output_path)

    # auto: prefer local Diffusers if available, then Gemini, then local placeholder.
    try:
        return _generate_diffusers(prompt, output_path)
    except Exception:
        try:
            return _generate_gemini_image(prompt, output_path)
        except Exception:
            return _placeholder_image(prompt, output_path, panel_number)
