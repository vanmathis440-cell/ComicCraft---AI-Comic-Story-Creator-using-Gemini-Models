from __future__ import annotations

import uuid
from pathlib import Path

from fpdf import FPDF

BASE_DIR = Path(__file__).resolve().parent.parent
EXPORT_DIR = BASE_DIR / "static" / "exports"


def _plain(text: str) -> str:
    """Convert common Unicode punctuation to text supported by Helvetica."""
    text = text or ""
    replacements = {
        "—": "-", "–": "-", "’": "'", "‘": "'",
        "“": '"', "”": '"', "…": "...",
        "•": "-", "₹": "Rs.",
        " ": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text.encode("latin-1", "replace").decode("latin-1")


def _local_image(path: str) -> Path:
    if path.startswith("/static/"):
        return BASE_DIR / path.lstrip("/")
    return Path(path)


def _write_text(pdf: FPDF, text: str, height: float = 6) -> None:
    """Write text using an explicit content width for FPDF2 compatibility."""
    pdf.set_x(pdf.l_margin)
    width = pdf.w - pdf.l_margin - pdf.r_margin
    pdf.multi_cell(width, height, _plain(text))


def save_pdf(layout: list[dict], title: str = "ComicCraft Comic") -> str:
    if not layout:
        raise ValueError("Comic layout cannot be empty.")

    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    filename = f"comic_{uuid.uuid4().hex[:12]}.pdf"
    output = EXPORT_DIR / filename

    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.set_margins(15, 15, 15)
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in layout:
        pdf.add_page()

        pdf.set_font("Helvetica", "B", 18)
        _write_text(pdf, f"Panel {panel['panel_number']}: {panel['title']}", 10)

        image_file = _local_image(panel["image_path"])
        if image_file.exists():
            x = pdf.l_margin
            y = pdf.get_y() + 3
            max_w, max_h = 180, 105
            pdf.image(str(image_file), x=x, y=y, w=max_w, h=max_h)
            pdf.set_y(y + max_h + 8)

        pdf.set_font("Helvetica", "I", 10)
        _write_text(pdf, panel.get("scene_description", ""), 6)
        pdf.ln(2)

        pdf.set_font("Helvetica", "B", 11)
        _write_text(pdf, "Caption", 6)
        pdf.set_font("Helvetica", "", 11)
        _write_text(pdf, panel.get("caption", ""), 6)
        pdf.ln(1)

        pdf.set_font("Helvetica", "B", 11)
        _write_text(pdf, "Narration", 6)
        pdf.set_font("Helvetica", "", 11)
        _write_text(pdf, panel.get("narration", ""), 6)

        if panel.get("dialogue"):
            pdf.ln(2)
            pdf.set_font("Helvetica", "B", 11)
            _write_text(pdf, "Dialogue", 6)
            pdf.set_font("Helvetica", "", 11)
            _write_text(pdf, panel.get("dialogue", ""), 6)

    pdf.output(str(output))
    return f"/static/exports/{filename}"
