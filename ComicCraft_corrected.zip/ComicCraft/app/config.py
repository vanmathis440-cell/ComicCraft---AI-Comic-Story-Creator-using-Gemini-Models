from pathlib import Path
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    gemini_api_key: str = ""
    hf_api_key: str = ""

    # Current Gemini models. These can be changed in .env without editing code.
    gemini_flash_model: str = "gemini-3.8-flash"
    gemini_pro_model: str = "gemini-3.1-pro-preview"

    # diffusers = local Hugging Face Diffusers, gemini = Gemini image model,
    # placeholder = local SVG placeholders. auto tries diffusers first, then Gemini.
    image_provider: str = "auto"
    hf_image_model: str = "stable-diffusion-v1-5/stable-diffusion-v1-5"
    gemini_image_model: str = "gemini-3.1-flash-image"

    image_width: int = 768
    image_height: int = 768
    image_steps: int = 20
    seed: int = 42

    model_device: str = "auto"
    app_name: str = "ComicCraft"

    model_config = SettingsConfigDict(
        env_file=BASE_DIR / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

@lru_cache
def get_settings() -> Settings:
    return Settings()
