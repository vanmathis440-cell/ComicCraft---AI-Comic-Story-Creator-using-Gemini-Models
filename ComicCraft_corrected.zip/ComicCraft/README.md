# ComicCraft - AI Comic Story Creator

ComicCraft is a FastAPI + Jinja2 web application that turns a user prompt into a five-panel comic. It follows the project documentation workflow:

1. Gemini Flash creates the structured five-panel outline.
2. Gemini Pro creates narration and dialogue.
3. Stable Diffusion creates panel illustrations.
4. The layout builder combines text and images.
5. FPDF2 creates the downloadable PDF.
6. Jinja2 renders the home, preview and export-success pages.

## Important current-integration note

The supplied project document uses older Gemini 1.5 examples. This corrected implementation uses Google's current `google-genai` SDK with the Interactions API for Gemini text/image generation. The current defaults are configurable in `.env`: `gemini-3.8-flash` for the outline, `gemini-3.1-pro-preview` for the expanded comic script, and `gemini-3.1-flash-image` for native image generation.

The Interactions API requires `google-genai` 2.3.0 or newer.

## Folder structure

```text
ComicCraft/
├── app/
│   ├── __init__.py
│   ├── config.py
│   ├── exporters.py
│   ├── gemini_flash.py
│   ├── gemini_pro.py
│   ├── image_generator.py
│   ├── layout_builder.py
│   ├── main.py
│   ├── routes.py
│   └── schemas.py
├── static/
│   ├── css/style.css
│   ├── js/app.js
│   ├── panels/
│   └── exports/
├── templates/
│   ├── index.html
│   ├── comic_preview.html
│   └── export_success.html
├── tests/
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Windows setup in VS Code

Open the `ComicCraft` folder in VS Code.

### 1. Create a virtual environment

```powershell
py -3.11 -m venv env
.\env\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt:

```cmd
env\Scripts\activate
```

### 2. Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

PyTorch installation can vary by GPU. If the full requirements installation fails specifically at `torch`, install the appropriate PyTorch build for your CPU/GPU first, then run the remaining requirements.

### 3. Create `.env`

Copy `.env.example` to `.env`.

For the easiest AI-image test, set:

```env
GEMINI_API_KEY=your_key_here
IMAGE_PROVIDER=gemini
GEMINI_IMAGE_MODEL=gemini-3.1-flash-image
```

Gemini's current image-generation documentation uses the Interactions API and `gemini-3.1-flash-image`.

For local Stable Diffusion, use:

```env
GEMINI_API_KEY=your_key_here
HF_API_KEY=your_huggingface_token_if_needed
IMAGE_PROVIDER=diffusers
```

For testing only, without image-model setup:

```env
IMAGE_PROVIDER=placeholder
```

The placeholder mode proves that FastAPI, Gemini text generation, panel layout and PDF export are connected before you configure image generation.

## 4. Start the server

```powershell
uvicorn app.main:app --reload
```

Open:

- http://127.0.0.1:8000
- http://127.0.0.1:8000/docs
- http://127.0.0.1:8000/health

## 5. Create a comic

Example:

Story Prompt:
`A brave fox discovers a glowing doorway in an enchanted forest and must rescue a lost bird.`

Character:
`Luna`

Setting:
`forest`

Tone:
`dramatic`

Art Style:
`comic book`

Click **Create My Comic**.

## 6. API test

In Swagger at `/docs`, use `POST /generate-comic/json` with:

```json
{
  "story_prompt": "A brave fox discovers a glowing doorway in an enchanted forest and must rescue a lost bird.",
  "character_name": "Luna",
  "setting": "forest",
  "tone": "dramatic",
  "art_style": "comic book"
}
```

## 7. Image-only test

Use `POST /test-image`:

```json
{
  "prompt": "A brave orange fox standing in an enchanted forest at sunset, professional comic book illustration, no text"
}
```

## Troubleshooting

### Gemini API key error

Make sure `.env` exists in the project root and contains `GEMINI_API_KEY`.

### Model not available

Change `GEMINI_FLASH_MODEL` or `GEMINI_PRO_MODEL` in `.env` to a model available to your Google AI account.

### Stable Diffusion is too slow

Local Diffusers can be very slow on CPU. Use a CUDA-capable PyTorch installation, use `IMAGE_PROVIDER=gemini`, or use `IMAGE_PROVIDER=placeholder` while testing the rest of the application.

### PDF contains replacement characters

The exporter uses FPDF2 core fonts for maximum portability. If you need full Unicode fonts, add a TTF/OTF font to the project and register it in `app/exporters.py`.

## Testing

Run:

```powershell
python -m pytest -q
```

The test suite checks the five-panel layout, PDF export, and local placeholder-image path without requiring a live AI request. The corrected package was validated with all local tests passing.
