from pathlib import Path

from PIL import Image

from app.layout_builder import build_comic_layout
from app.exporters import save_pdf


def sample_story():
    return [
        {
            "panel_number": i,
            "title": f"Panel {i}",
            "scene_description": "A comic scene.",
            "caption": "A caption.",
            "narration": "A short narration.",
            "dialogue": "Hello!",
            "image_prompt": "A comic illustration.",
        }
        for i in range(1, 6)
    ]


def test_layout_has_five_panels():
    layout = build_comic_layout(
        sample_story(),
        [f"/static/panels/{i}.png" for i in range(1, 6)],
    )
    assert len(layout) == 5
    assert layout[0]["panel_number"] == 1
    assert layout[-1]["panel_number"] == 5


def test_pdf_export(tmp_path, monkeypatch):
    import app.exporters as exporters

    monkeypatch.setattr(exporters, "EXPORT_DIR", tmp_path)

    layout = build_comic_layout(sample_story(), ["/missing/1.png"] * 5)
    pdf_path = save_pdf(layout)

    assert pdf_path.startswith("/static/exports/")
    pdf_file = tmp_path / Path(pdf_path).name
    assert pdf_file.exists()
    assert pdf_file.stat().st_size > 0


def test_placeholder_image(tmp_path, monkeypatch):
    import app.image_generator as image_generator

    monkeypatch.setattr(image_generator, "PANEL_DIR", tmp_path)
    monkeypatch.setattr(image_generator.settings, "image_width", 320)
    monkeypatch.setattr(image_generator.settings, "image_height", 320)
    monkeypatch.setattr(image_generator.settings, "image_provider", "placeholder")

    image_path = image_generator.generate_image("A comic robot in a college", 1)
    output = tmp_path / Path(image_path).name

    assert image_path.startswith("/static/panels/")
    assert output.exists()
    with Image.open(output) as image:
        assert image.size == (320, 320)
