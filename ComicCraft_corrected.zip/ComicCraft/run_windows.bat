@echo off
if not exist env (
  py -3.11 -m venv env
)
call env\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn app.main:app --reload
