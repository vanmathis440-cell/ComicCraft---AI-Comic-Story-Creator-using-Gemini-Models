if (!(Test-Path "env")) {
    py -3.11 -m venv env
}
& ".\env\Scripts\Activate.ps1"
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn app.main:app --reload
