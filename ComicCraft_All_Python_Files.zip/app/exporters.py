from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List
from fpdf import FPDF
from .config import settings

def _safe_pdf_text(value: Any) -> str:
    text = "" if value is None else str(value)
    for old, new in {"—":"-", "–":"-", "“":'"', "”":'"', "‘":"'", "’":"'", "…":"...", "•":"*", "→":"->", "←":"<-"}.items():
        text = text.replace(old, new)
    return text.encode("latin-1", errors="replace").decode("latin-1")

class ComicPDF(FPDF):
    def header(self):
        self.set_font("Helvetica", "B", 16)
        self.cell(0, 10, "ComicCraft", align="C")
        self.ln(12)

def save_pdf(layout: List[Dict[str, Any]], filename: str | None = None) -> str:
    settings.EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
    filename = filename or f"comiccraft_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    if not filename.lower().endswith(".pdf"): filename += ".pdf"
    output = settings.EXPORTS_DIR / filename
    pdf = ComicPDF("P", "mm", "A4")
    pdf.set_auto_page_break(True, 15)
    pdf.set_margins(15, 15, 15)
    for panel in layout:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 15)
        pdf.multi_cell(0, 9, _safe_pdf_text(f"Panel {panel.get('panel_number','')}: {panel.get('title','')}"), align="C")
        pdf.ln(5)
        image_path = Path(panel.get("image_path", ""))
        if image_path.exists():
            try:
                pdf.image(str(image_path), x=15, y=pdf.get_y(), w=180, h=105)
                pdf.ln(113)
            except Exception:
                pdf.set_font("Helvetica", "", 10)
                pdf.multi_cell(0, 6, "Image could not be embedded.")
                pdf.ln(5)
        for label, key, bold in [
            ("Scene", "scene_description", False),
            ("Caption", "caption", True),
            ("Narration", "narration", False),
            ("Dialogue", "dialogue", True),
        ]:
            value = _safe_pdf_text(panel.get(key, ""))
            if value:
                pdf.set_font("Helvetica", "B" if bold else "", 10)
                pdf.multi_cell(0, 6, f"{label}: {value}")
                pdf.ln(2)
    pdf.output(str(output))
    return str(output)
