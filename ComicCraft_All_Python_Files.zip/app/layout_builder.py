from pathlib import Path
from typing import Any, Dict, List

def build_comic_layout(story: List[Dict[str, Any]], image_paths: List[str]) -> List[Dict[str, Any]]:
    if len(story) != len(image_paths):
        raise ValueError("Number of story panels and images must match.")
    return [
        {
            "panel_number": panel.get("panel_number"),
            "title": panel.get("title", ""),
            "image_path": str(Path(image_path)),
            "scene_description": panel.get("scene_description", ""),
            "caption": panel.get("caption", ""),
            "narration": panel.get("narration", ""),
            "dialogue": panel.get("dialogue", ""),
            "image_prompt": panel.get("image_prompt", ""),
        }
        for panel, image_path in zip(story, image_paths)
    ]
