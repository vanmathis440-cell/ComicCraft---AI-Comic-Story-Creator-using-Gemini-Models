import json
from typing import Any, Dict, List
from google import genai
from google.genai import types
from .config import settings

def _client():
    if not settings.GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY is missing. Add it to .env.")
    return genai.Client(api_key=settings.GEMINI_API_KEY)

def _text(response):
    if getattr(response, "text", None):
        return response.text
    try:
        return "".join(
            p.text for p in response.candidates[0].content.parts
            if getattr(p, "text", None)
        )
    except Exception as exc:
        raise RuntimeError("Gemini returned an empty response.") from exc

def _clean(text: str) -> str:
    text = text.strip()
    if text.startswith("```json"): text = text[7:]
    elif text.startswith("```"): text = text[3:]
    if text.endswith("```"): text = text[:-3]
    return text.strip()

def generate_story(story_prompt: str, character_name: str, setting: str,
                   tone: str, art_style: str,
                   outline: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    outline_json = json.dumps(outline, indent=2, ensure_ascii=False)
    prompt = f"""Create the detailed story for an EXACTLY 5-panel comic.

Story prompt: {story_prompt}
Main character: {character_name}
Setting: {setting}
Tone: {tone}
Art style: {art_style}

Outline:
{outline_json}

For each panel return panel_number, title, scene_description, caption,
narration, dialogue and image_prompt. Preserve continuity. Return ONLY JSON:
{{"panels":[{{"panel_number":1,"title":"...","scene_description":"...",
"caption":"...","narration":"...","dialogue":"...","image_prompt":"..."}}]}}"""
    response = _client().models.generate_content(
        model=settings.GEMINI_PRO_MODEL,
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=0.8,
            response_mime_type="application/json",
        ),
    )
    try:
        data = json.loads(_clean(_text(response)))
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Invalid Gemini story JSON: {exc}") from exc
    panels = data.get("panels")
    if not isinstance(panels, list) or len(panels) != 5:
        raise RuntimeError("Gemini must return exactly 5 story panels.")
    return panels
