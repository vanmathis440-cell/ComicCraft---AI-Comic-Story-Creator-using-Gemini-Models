import base64
import hashlib
import re
from pathlib import Path
from typing import Optional
from PIL import Image, ImageDraw, ImageFont
from .config import settings

def _safe_filename(prompt: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9_-]+", "_", prompt).strip("_") or "comic_panel"
    digest = hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:10]
    return f"{cleaned[:60]}_{digest}.png"

def _generate_with_gemini(prompt: str, output_path: Path) -> str:
    from google import genai
    if not settings.GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY is missing.")
    client = genai.Client(api_key=settings.GEMINI_API_KEY)
    interaction = client.interactions.create(
        model=settings.GEMINI_IMAGE_MODEL,
        input=prompt,
        response_format={"type": "image", "aspect_ratio": "1:1", "image_size": "1K"},
    )
    image = getattr(interaction, "output_image", None)
    data = getattr(image, "data", None) if image else None
    if not data:
        raise RuntimeError("Gemini did not return image data.")
    output_path.write_bytes(base64.b64decode(data))
    return str(output_path)

def _get_diffusers_pipeline():
    global _DIFFUSERS_PIPELINE
    if _DIFFUSERS_PIPELINE is not None:
        return _DIFFUSERS_PIPELINE
    import torch
    from diffusers import StableDiffusionPipeline
    kwargs = {"token": settings.HF_API_KEY} if settings.HF_API_KEY else {}
    pipe = StableDiffusionPipeline.from_pretrained(settings.HF_IMAGE_MODEL, **kwargs)
    pipe = pipe.to("cuda" if torch.cuda.is_available() else "cpu")
    _DIFFUSERS_PIPELINE = pipe
    return pipe

_DIFFUSERS_PIPELINE = None

def _generate_with_diffusers(prompt: str, output_path: Path) -> str:
    import torch
    pipe = _get_diffusers_pipeline()
    generator = torch.Generator(device="cuda" if torch.cuda.is_available() else "cpu").manual_seed(settings.IMAGE_SEED)
    image = pipe(prompt=prompt, height=settings.IMAGE_HEIGHT, width=settings.IMAGE_WIDTH,
                 num_inference_steps=settings.IMAGE_STEPS, generator=generator).images[0]
    image.save(output_path)
    return str(output_path)

def _generate_placeholder(prompt: str, output_path: Path) -> str:
    image = Image.new("RGB", (settings.IMAGE_WIDTH, settings.IMAGE_HEIGHT), "white")
    draw = ImageDraw.Draw(image)
    draw.rectangle([10, 10, settings.IMAGE_WIDTH-10, settings.IMAGE_HEIGHT-10], outline="black", width=5)
    try: font = ImageFont.truetype("arial.ttf", 32)
    except Exception: font = ImageFont.load_default()
    draw.text((40, 40), "ComicCraft", fill="black", font=font)
    words, lines, current = prompt.split(), [], ""
    for word in words:
        test = f"{current} {word}".strip()
        if len(test) > 45:
            lines.append(current); current = word
        else: current = test
    if current: lines.append(current)
    y = 120
    for line in lines[:15]:
        draw.text((40, y), line, fill="black", font=font); y += 45
    image.save(output_path)
    return str(output_path)

def generate_image(image_prompt: str, panel_number: Optional[int] = None) -> str:
    settings.PANELS_DIR.mkdir(parents=True, exist_ok=True)
    filename = _safe_filename(image_prompt)
    if panel_number is not None:
        filename = f"panel_{panel_number}_{filename}"
    output_path = settings.PANELS_DIR / filename
    if settings.IMAGE_PROVIDER == "gemini":
        return _generate_with_gemini(image_prompt, output_path)
    if settings.IMAGE_PROVIDER == "diffusers":
        return _generate_with_diffusers(image_prompt, output_path)
    if settings.IMAGE_PROVIDER == "placeholder":
        return _generate_placeholder(image_prompt, output_path)
    raise ValueError("IMAGE_PROVIDER must be gemini, diffusers, or placeholder.")
