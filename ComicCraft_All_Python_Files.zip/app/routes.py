from pathlib import Path
from typing import Any, Dict, List
from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from .config import settings
from .exporters import save_pdf
from .gemini_flash import generate_outline
from .gemini_pro import generate_story
from .image_generator import generate_image
from .layout_builder import build_comic_layout
from .schemas import PromptRequest

router = APIRouter()
templates = Jinja2Templates(directory=str(settings.TEMPLATES_DIR))

def _generate_comic(story_prompt: str, character_name: str, setting: str, tone: str, art_style: str) -> Dict[str, Any]:
    outline = generate_outline(story_prompt, character_name, setting, tone, art_style)
    story = generate_story(story_prompt, character_name, setting, tone, art_style, outline)
    image_paths: List[str] = []
    for panel in story:
        image_paths.append(generate_image(panel["image_prompt"], panel["panel_number"]))
    layout = build_comic_layout(story, image_paths)
    pdf_path = save_pdf(layout)
    return {"outline": outline, "story": story, "layout": layout, "pdf_path": pdf_path}

@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={"title": "ComicCraft"})

@router.post("/generate", response_class=HTMLResponse)
async def generate_comic(request: Request, story_prompt: str = Form(...), character_name: str = Form(...),
                         setting: str = Form(...), tone: str = Form(...), art_style: str = Form(...)):
    try:
        result = _generate_comic(story_prompt, character_name, setting, tone, art_style)
        return templates.TemplateResponse(request=request, name="comic_preview.html",
            context={"title": "Comic Preview", "layout": result["layout"], "pdf_path": result["pdf_path"]})
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Comic generation failed: {exc}") from exc

@router.post("/generate-comic/json")
async def generate_comic_json(data: PromptRequest):
    try:
        result = _generate_comic(data.story_prompt, data.character_name, data.setting, data.tone, data.art_style)
        pdf = Path(result["pdf_path"])
        return {"success": True, "message": "Comic generated successfully.", "layout": result["layout"],
                "pdf_path": str(pdf), "pdf_url": f"/download/{pdf.name}"}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Comic generation failed: {exc}") from exc

@router.get("/test-image")
async def test_image(prompt: str = "A brave fox exploring an enchanted forest, comic book style"):
    try:
        path = Path(generate_image(prompt, 0))
        return {"success": True, "image_path": str(path), "image_url": f"/static/panels/{path.name}"}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Image generation failed: {exc}") from exc

@router.get("/download/{filename}")
async def download_pdf(filename: str):
    safe = Path(filename).name
    path = settings.EXPORTS_DIR / safe
    if not path.exists():
        raise HTTPException(status_code=404, detail="PDF file not found.")
    return FileResponse(str(path), media_type="application/pdf", filename=safe)

@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request, pdf: str = ""):
    return templates.TemplateResponse(request=request, name="export_success.html",
                                      context={"title": "Export Successful", "pdf": pdf})
