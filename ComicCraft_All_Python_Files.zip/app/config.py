import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

class Settings:
    APP_NAME = "ComicCraft - AI Comic Story Creator"
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
    HF_API_KEY = os.getenv("HF_API_KEY", "")
    GEMINI_FLASH_MODEL = os.getenv("GEMINI_FLASH_MODEL", "gemini-3.8-flash")
    GEMINI_PRO_MODEL = os.getenv("GEMINI_PRO_MODEL", "gemini-3.1-pro-preview")
    GEMINI_IMAGE_MODEL = os.getenv("GEMINI_IMAGE_MODEL", "gemini-3.1-flash-image")
    IMAGE_PROVIDER = os.getenv("IMAGE_PROVIDER", "gemini").lower()
    HF_IMAGE_MODEL = os.getenv("HF_IMAGE_MODEL", "runwayml/stable-diffusion-v1-5")
    IMAGE_WIDTH = int(os.getenv("IMAGE_WIDTH", "768"))
    IMAGE_HEIGHT = int(os.getenv("IMAGE_HEIGHT", "768"))
    IMAGE_STEPS = int(os.getenv("IMAGE_STEPS", "20"))
    IMAGE_SEED = int(os.getenv("IMAGE_SEED", "42"))
    STATIC_DIR = BASE_DIR / "static"
    PANELS_DIR = STATIC_DIR / "panels"
    EXPORTS_DIR = STATIC_DIR / "exports"
    TEMPLATES_DIR = BASE_DIR / "templates"

    def __init__(self):
        self.STATIC_DIR.mkdir(parents=True, exist_ok=True)
        self.PANELS_DIR.mkdir(parents=True, exist_ok=True)
        self.EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
        self.TEMPLATES_DIR.mkdir(parents=True, exist_ok=True)

settings = Settings()
