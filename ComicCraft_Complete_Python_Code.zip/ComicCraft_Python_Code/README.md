# ComicCraft – AI Comic Story Creator using Gemini Models

Python backend files for the SmartBridge ComicCraft project.

## Run
python -m venv env
env\Scripts\activate
pip install -r requirements.txt

Copy `.env.example` to `.env` and add your Gemini API key.

Then:
uvicorn app.main:app --reload

Open http://127.0.0.1:8000
